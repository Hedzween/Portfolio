package com.example.kfries2.model;

public class Orders {
    private int OrderID;
    private int orderItems;
    private int orderStatus;
    private String OrderDate;
    private String Remarks;
    private String OrderTime;
    private String TotalPrice;
    private int Users;

    public Orders() {
    }

    public Orders(int orderID, int orderItemsID, int statusID, String orderDate,  String remark, String orderTime, String totalPrice,int User) {
        OrderID = orderID;
        orderItems = orderItemsID;
        orderStatus = statusID;
        OrderDate = orderDate;
        Remarks = remark;
        OrderTime = orderTime;
        TotalPrice = totalPrice;
        Users=User;
    }

    public String getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int orderID) {
        OrderID = orderID;
    }

    public int getOrderItemsID() {
        return orderItems;
    }

    public void setOrderItemsID(int orderItemsID) {
        orderItems = orderItemsID;
    }

    public int getStatusID() {
        return orderStatus;
    }

    public void setStatusID(int statusID) {
        orderStatus = statusID;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String orderDate) {
        OrderDate = orderDate;
    }

    public String getRemark() {
        return Remarks;
    }

    public void setRemark(String remark) {
        Remarks = remark;
    }

    public String getOrderTime() {
        return OrderTime;
    }

    public void setOrderTime(String orderTime) {
        OrderTime = orderTime;
    }

    public int getUser() {
        return Users;
    }

    public void setUser(int user) {
        this.Users = user;
    }

    @Override
    public String toString() {
        return "Orders{" +
                "OrderID=" + OrderID +
                ", orderItems=" + orderItems +
                ", orderStatus=" + orderStatus +
                ", OrderDate='" + OrderDate + '\'' +
                ", Remarks='" + Remarks + '\'' +
                ", OrderTime='" + OrderTime + '\'' +
                ", TotalPrice='" + TotalPrice + '\'' +
                ", user=" + Users +
                '}';
    }
}
