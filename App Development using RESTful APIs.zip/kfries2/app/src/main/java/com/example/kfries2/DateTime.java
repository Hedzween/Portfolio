package com.example.kfries2;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateTime {
    private String currentDate;
    private String currentTime;
    private SimpleDateFormat timeFormat; // Added this line

    public DateTime(String currentDate, String currentTime) {
        this.currentDate = currentDate;
        this.currentTime = currentTime;
        this.timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()); // Added this line
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public String getCurrentTime() {
        return currentTime;
    }
    public Date toDate() throws ParseException {
        return timeFormat.parse(currentTime);
    }
    public int getHours() {
        if (currentTime != null) {
            String[] timeComponents = currentTime.split(":");
            if (timeComponents.length == 3) {
                try {
                    return Integer.parseInt(timeComponents[0]);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return 0; // Return a default value if parsing fails
    }

    public int getMinutes() {
        if (currentTime != null) {
            String[] timeComponents = currentTime.split(":");
            if (timeComponents.length == 3) {
                try {
                    return Integer.parseInt(timeComponents[1]);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return 0; // Return a default value if parsing fails
    }
    public String adjustTimeIfMoreThanSevenMinutes() {
        try {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(timeFormat.parse(currentTime));

            int minutesToAdd = 7;
            calendar.add(Calendar.MINUTE, minutesToAdd);

            // Format the adjusted time back to a string
            currentTime = timeFormat.format(calendar.getTime());

            // Log the adjusted time for debugging
            Log.d("MyApp:", "Adjusted Time: " + currentTime);

        } catch (ParseException e) {
            e.printStackTrace();
            // Handle the parse exception if needed
        }
        return currentTime;
    }
    public int getSeconds() {
        if (currentTime != null) {
            String[] timeComponents = currentTime.split(":");
            if (timeComponents.length == 3) {
                try {
                    return Integer.parseInt(timeComponents[2]);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        }
        return 0; // Return a default value if parsing fails
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }
}
