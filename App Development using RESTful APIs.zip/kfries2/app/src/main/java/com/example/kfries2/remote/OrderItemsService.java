package com.example.kfries2.remote;

import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.OrderItems;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface OrderItemsService {
    @POST("api/OrderItems")
    Call<OrderItems> addOrderItems(@Header("api-key")String apiKey, @Body OrderItems OrderItems);

    @POST("api/OrderItems/delete/{OrderItemsID}")
    Call<DeleteResponse> deleteOrderItems(@Header("api-key")String apikey, @Path("OrderItemsID") int OrderItemsID);
}
