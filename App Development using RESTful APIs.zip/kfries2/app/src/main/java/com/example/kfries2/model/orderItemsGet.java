package com.example.kfries2.model;

public class orderItemsGet {
    private int OrderItemsID;
    private Items Items;
    private int Quantity;

    public orderItemsGet() {
    }

    public orderItemsGet(int orderItemsID, com.example.kfries2.model.Items items, int quantity) {
        OrderItemsID = orderItemsID;
        Items = items;
        Quantity = quantity;
    }

    public int getOrderItemsID() {
        return OrderItemsID;
    }

    public void setOrderItemsID(int OrderItemsID) {
        this.OrderItemsID = OrderItemsID;
    }

    public com.example.kfries2.model.Items getItems() {
        return Items;
    }

    public void setItems(com.example.kfries2.model.Items items) {
        Items = items;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    @Override
    public String toString() {
        return "orderItemsGet{" +
                "OrderItemsID=" + OrderItemsID +
                ", Items=" + Items +
                ", Quantity=" + Quantity +
                '}';
    }
}
