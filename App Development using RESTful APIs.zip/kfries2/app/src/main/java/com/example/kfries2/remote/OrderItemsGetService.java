package com.example.kfries2.remote;

import com.example.kfries2.model.orderItemsGet;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface OrderItemsGetService {
    @GET("api/OrderItems")
    Call<List<orderItemsGet>> getAllOrderItems(@Header("api-key")String apiKey);
}
