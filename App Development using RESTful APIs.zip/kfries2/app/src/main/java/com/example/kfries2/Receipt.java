package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.kfries2.adapter.OrderAdapter;
import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.OrderItems;
import com.example.kfries2.model.Orders;
import com.example.kfries2.model.SalesDaily;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.orderget;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.CartService;
import com.example.kfries2.remote.OrderGetService;
import com.example.kfries2.remote.OrderItemsService;
import com.example.kfries2.remote.OrderService;
import com.example.kfries2.remote.SalesDailyService;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Receipt extends AppCompatActivity {

    private Context context;
    private OrderAdapter orderAdapter;
    private RecyclerView itemReceipt;
    private OrderGetService orderGetService;
    private OrderService orderService;
    private CartService cartService;
    private OrderItemsService orderItemsService;
    private SalesDailyService salesDailyService;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    String totalString="";

    int currentPos;
    private static class GifListener implements RequestListener<GifDrawable> {
        @Override
        public boolean onLoadFailed(@androidx.annotation.Nullable GlideException e, Object model, Target<GifDrawable> target, boolean isFirstResource) {
            return false;
        }

        @Override
        public boolean onResourceReady(GifDrawable resource, Object model, Target<GifDrawable> target, DataSource dataSource, boolean isFirstResource) {
            // Set the GIF to loop indefinitely
            resource.setLoopCount(GifDrawable.LOOP_FOREVER);
            return false;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
        context=this;
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        TextView name=findViewById(R.id.user);
        name.setText(user.getUsername());

        TextView total=findViewById(R.id.TotalPrice1);
        total.setText("RM"+totalString);

        itemReceipt=findViewById(R.id.itemReceipt);
        registerForContextMenu(itemReceipt);
        updateListView();

        orderGetService= ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("MyApp: ","Response: "+response.raw().toString());
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }
                List<orderget> ordergets=response.body();
                List<orderget> filteredOrders = filterOrderByUserID(ordergets, user.getId());
                if(ordergets!= null) {
                    for (orderget order : filteredOrders) {

                            TextView tvStatus = findViewById(R.id.status);
                            tvStatus.setText(order.getStatusID().getStatusName());
                            TextView OrderDate = findViewById(R.id.OrderDate);
                            OrderDate.setText(order.getOrderDate());
                            TextView OrderTime = findViewById(R.id.OrderTime);
                            OrderTime.setText(order.getOrderTime());
                            TextView remark = findViewById(R.id.remark);
                            remark.setText(order.getRemarks());
                            total.setText("RM" + order.getTotalPrice());
                    }
                }

                    orderAdapter = new OrderAdapter(context, filteredOrders);
                    itemReceipt.setAdapter(orderAdapter);
                    LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    itemReceipt.setLayoutManager(layoutManager);

            }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_SHORT);
                Log.e("MyApp: ", t.getMessage());
            }
        });
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view1);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {
                    // Handle "My Account" click
                    // Add your logic here
                }else if (id==R.id.Cart) {
                    doCart1();
                }else if (id==R.id.myOrder) {
                    doOrder();
                }
                else if (id == R.id.nav_settings) {
                    // Handle "Settings" click
                    // Add your logic here
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }

                // Close the drawer after handling item click
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {

        // clear the shared preferences
        SharedPrefManager.getInstance(getApplicationContext()).logout();

        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        // forward to LoginActivity
        finish();
        startActivity(new Intent(getApplicationContext(), login.class));
    }
    public void doCart1() {
        startActivity(new Intent(this, Cart.class));
        finish();
    }
    public void doOrder() {
        startActivity(new Intent(this, Receipt.class));
        finish();
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void updateListView(){
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderGetService = ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("MyApp: ","Response: "+response.raw().toString());
                if(response.code()==401){
                    displayAlert("Session Invalid");
                }
                List<orderget> ordergets = response.body();
                List<Integer> orderIDs = new ArrayList<>();
                List<Integer> orders = new ArrayList<>();
                List<orderget> filteredOrders = filterOrderByUserID(ordergets, user.getId());
                for (orderget order : filteredOrders) {
                    orderIDs.add(order.getOrderID());
                    orders.add(order.getOrderItemsID().getOrderItemsID());
                    int statusDrawableResource;
                    Button btnCancel = findViewById(R.id.Cancel);
                    Button btnReceive = findViewById(R.id.Receive);
                    if (order.getStatusID().getStatusID()==1) {
                        statusDrawableResource = R.drawable.newstatus;
                        btnCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                removeOrder(orderIDs,user,orders);
                                Toast.makeText(context,"Order has been deleted :(",Toast.LENGTH_SHORT).show();
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Intent intent = new Intent(context, mainmenu.class);
                                        startActivity(intent);
                                    }
                                }, 2000);
                            }
                        });
                        btnReceive.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(context, "Your order is still in process", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else if (order.getStatusID().getStatusID()==2) {
                        statusDrawableResource = R.drawable.orderprocess;
                        btnCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(context, "Your order has already been processed", Toast.LENGTH_SHORT).show();
                            }
                        });
                        btnReceive.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                saveSales(order.getTotalPrice(),orderIDs,orders);
                                displayAlert("Thank You For Your Order");
                                Intent intent = new Intent(context,mainmenu.class);
                                startActivity(intent);
                            }
                        });
                    } else {
                        // Default or unknown status
                        statusDrawableResource = R.drawable.orderready;
                        btnReceive.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                displayAlert("Thank You For Your Order");
                                removeOrder(orderIDs,user,orders);
                                Intent intent = new Intent(context,mainmenu.class);
                                startActivity(intent);
                            }
                        });
                    }

                    ImageView imageView = findViewById(R.id.imageStatus);
                    Glide.with(Receipt.this)
                            .asGif()
                            .load(statusDrawableResource)
                            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                            .listener(new GifListener())
                            .into(imageView);
                }

                    orderAdapter = new OrderAdapter(context, filteredOrders);
                    itemReceipt.setAdapter(orderAdapter);
                    LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    itemReceipt.setLayoutManager(layoutManager);
                }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }
    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void removeOrder(List<Integer> orderId,User user,List<Integer> order1){
        orderService = ApiUtils.getOrderService();
        for(Integer orders: orderId) {
            Call<DeleteResponse> deleteResponseCall = orderService.deleteOrder(user.getToken(), orders);
            deleteResponseCall.enqueue(new Callback<DeleteResponse>() {
                @Override
                public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                    if(response.isSuccessful()){
                        removeOrderItems(user,order1);

                    }
                    else {
                        Log.e("Receipt:", "Delete Failed. Error Code: "+response.code());
                    }
                }

                @Override
                public void onFailure(Call<DeleteResponse> call, Throwable t) {
                    Log.e("Receipt:", "Delete Failed. Error Code: "+t.getMessage());
                }
            });
        }
    }
    public void removeOrderItems(User user,List<Integer> OrderItemsId){
        orderItemsService=ApiUtils.getOrderItemsService();
        for(Integer orderId:OrderItemsId) {
            Call<DeleteResponse> deleteResponseCall = orderItemsService.deleteOrderItems(user.getToken(),orderId );
            deleteResponseCall.enqueue(new Callback<DeleteResponse>() {
                @Override
                public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                    if(response.isSuccessful()){
                        Log.d("Receipt:","Delete Order Item: "+response.code());
                    }
                    else{
                        Log.e("Receipt:", "Delete Order Items failed. Error code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<DeleteResponse> call, Throwable t) {
                    Log.e("Receipt", "Delete failed. Error: " + t.getMessage());
                }
            });
        }
    }

    private void saveSales(String total,List<Integer> orderId,List<Integer> order1) {
        try {
            // Parse the total string to ensure it's a valid number
            BigDecimal totalValue = new BigDecimal(total);

            TimeZone malaysiaTimeZone = TimeZone.getTimeZone("GMT+08:00");
            Calendar currentDateTime = Calendar.getInstance(malaysiaTimeZone);

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
            String currentDateString = dateFormat.format(currentDateTime.getTime());

            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTimeString = timeFormat.format(currentDateTime.getTime());

            User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();

            salesDailyService = ApiUtils.getSalesDailyService();
            SalesDaily salesDaily = new SalesDaily(0, totalValue, currentDateString);

            Log.d("AdminMenu:", "SalesDaily: " + salesDaily.toString());

            salesDailyService.addSales(user.getToken(), salesDaily).enqueue(new Callback<SalesDaily>() {
                @Override
                public void onResponse(Call<SalesDaily> call, Response<SalesDaily> response) {
                    if (response.isSuccessful() || response.code() == 201) {
                        Log.d("MyApp:", "Sales noted down successfully");
                        removeOrder(orderId,user,order1);
                    } else {
                        try {
                            Log.d("MyApp:", "Error Response Code: " + response.code());
                            Log.d("MyApp:", "Error Response Message: " + response.errorBody().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onFailure(Call<SalesDaily> call, Throwable t) {
                    Log.e("MyApp:", "Order failed. Error: " + t.getMessage());
                }
            });
        } catch (NumberFormatException e) {
            Log.e("MyApp:", "Invalid 'total' value: " + total);
        }
    }
    private List<orderget> filterOrderByUserID(List<orderget> orderlist, int userID){
        List<orderget> filteredList = new ArrayList<>();
        for(orderget order: orderlist){
            if (order.getUsers() != null && order.getUsers().getId() == userID) {
                filteredList.add(order);
            }
        }
        return filteredList;
    }

}