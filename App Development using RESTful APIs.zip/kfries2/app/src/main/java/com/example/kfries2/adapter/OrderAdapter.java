package com.example.kfries2.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.kfries2.R;
import com.example.kfries2.model.Orders;
import com.example.kfries2.model.orderget;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {
    private List<orderget> orderList;
    private Context mContext;
    private int currentPos;
    public int getCurrentPos() {
        return currentPos;
    }
    private Context getmContext(){return mContext;}
    public Integer[] getResourceId(){return resourceId;}
    private Integer resourceId[] ={R.drawable.bibimbap,R.drawable.kongguksu,R.drawable.naengmyeon,R.drawable.gimbap,
            R.drawable.jjangmyeon,R.drawable.bulgogi,R.drawable.peachsoda,R.drawable.bananamilk,R.drawable.strawberrymilk,
            R.drawable.melonmilk,R.drawable.kimchi,R.drawable.tteok,R.drawable.tteokbokki
    };
    public OrderAdapter(Context context, List<orderget> listData){
        orderList=listData;
        mContext=context;
    }
    public List<orderget> getOrderList(){return orderList;}
    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.receipt_single_layout, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder( ViewHolder holder, int position) {
        orderget orderget = orderList.get(position);
        if(orderget.getOrderItemsID()!=null){
            Log.d("MyApp: ","OrderItemId: "+orderget.getOrderItemsID().getOrderItemsID());
            Log.d("MyApp","Status ID: "+orderget.getStatusID().getStatusName());
            BigDecimal price= orderget.getOrderItemsID().getItems().getPrices();
            int quantity=orderget.getOrderItemsID().getQuantity();
            BigDecimal Price = price.multiply(new BigDecimal(quantity));
            String TotalPrice = String.format("RM %.2f", Price);
            String itemName =orderget.getOrderItemsID().getItems().getItemName();
            holder.tvItemsName.setText(itemName);
            holder.tvItemPrice.setText(TotalPrice);
            holder.tvQuantity.setText("x"+quantity);
            setImageResourceBasedOnItemName(holder, itemName);
        }
        else {
            Log.e("MyApp", "Items object is null for position: " + position);
            holder.itemView.setVisibility(View.GONE);
        }
    }
    private void setImageResourceBasedOnItemName(ViewHolder holder, String itemName) {
        Integer currResource = null;

        // Assuming that the ItemName and resourceId arrays have the same order
        for (int i = 0; i < resourceId.length; i++) {
            String resourceName = mContext.getResources().getResourceEntryName(resourceId[i]).toLowerCase();

            if (itemName.toLowerCase().replaceAll("\\s", "").equals(resourceName.toLowerCase().replaceAll("\\s", ""))) {
                currResource = resourceId[i];
                break;
            }
        }

        if (currResource != null) {
            holder.itemsImage.setImageResource(currResource);
        } else {
            // Handle the case where the resource for the itemName is not found
            // You may set a default image or handle it as needed
            holder.itemsImage.setImageResource(R.drawable.logo);
        }
    }
    @Override
    public int getItemCount() {
        return orderList != null ? orderList.size() : 0;
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemsImage;
        TextView tvItemsName;
        TextView tvItemPrice;
        TextView tvQuantity;
        public ViewHolder(View orderView){
            super(orderView);
            itemsImage = (ImageView) orderView.findViewById(R.id.itemsImage);
            tvItemsName = (TextView) orderView.findViewById(R.id.tvItemNames);
            tvItemPrice = (TextView)orderView.findViewById(R.id.tvItemPrice);
            tvQuantity= (TextView)orderView.findViewById(R.id.tvQuantity);

        }
    }
}
