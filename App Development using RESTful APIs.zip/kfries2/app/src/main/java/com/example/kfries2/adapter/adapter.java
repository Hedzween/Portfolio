package com.example.kfries2.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kfries2.R;
import com.example.kfries2.model.orderget;

import java.math.BigDecimal;
import java.util.List;

public class adapter extends RecyclerView.Adapter<adapter.ViewHolder> {
    private List<orderget> orderList;
    private Context mContext;
    private Integer resourceId[] = {
            R.drawable.bibimbap, R.drawable.kongguksu, R.drawable.naengmyeon, R.drawable.gimbap,
            R.drawable.jjangmyeon, R.drawable.bulgogi, R.drawable.peachsoda, R.drawable.bananamilk, R.drawable.strawberrymilk,
            R.drawable.melonmilk, R.drawable.kimchi, R.drawable.tteok, R.drawable.tteokbokki
    };

    public adapter(Context context, List<orderget> listData) {
        orderList = listData;
        mContext = context;
    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.receipt_single_layout, parent, false);

        // Return a new holder instance
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        orderget orderget = orderList.get(position);

        Log.d("MyAdapter", "Position: " + position + ", Order: " + orderget);

        if (orderget != null && orderget.getUsers() != null && orderget.getOrderItemsID() != null
                && orderget.getOrderItemsID().getItems() != null) {

                BigDecimal price = orderget.getOrderItemsID().getItems().getPrices();
                int quantity = orderget.getOrderItemsID().getQuantity();

                Log.d("MyAdapter", "Price: " + price + ", Quantity: " + quantity);

                if (price != null) {
                    BigDecimal totalPrice = price.multiply(new BigDecimal(quantity));

                    Log.d("MyAdapter", "Total Price: " + totalPrice);

                    holder.tvItemsName.setText(orderget.getOrderItemsID().getItems().getItemName());
                    holder.tvItemPrice.setText(String.format("RM %.2f", totalPrice));
                    holder.tvQuantity.setText("x" + quantity);
                    setImageResourceBasedOnItemName(holder, orderget.getOrderItemsID().getItems().getItemName());
                    holder.itemView.setVisibility(View.VISIBLE); // Set visibility to VISIBLE
                } else {
                    // Handle the case where price is null
                    holder.itemView.setVisibility(View.GONE); // Hide the itemView if price is null
                }
        }
            else {
            // Hide the itemView if OrderItemsID or related objects are null
            holder.itemView.setVisibility(View.GONE);
        }
    }




    private void setImageResourceBasedOnItemName(ViewHolder holder, String itemName) {
        Integer currResource = null;

        // Assuming that the ItemName and resourceId arrays have the same order
        for (int i = 0; i < resourceId.length; i++) {
            String resourceName = mContext.getResources().getResourceEntryName(resourceId[i]).toLowerCase();

            if (itemName.toLowerCase().replaceAll("\\s", "").equals(resourceName.toLowerCase().replaceAll("\\s", ""))) {
                currResource = resourceId[i];
                break;
            }
        }

        if (currResource != null) {
            holder.itemsImage.setImageResource(currResource);
        } else {
            // Handle the case where the resource for the itemName is not found
            // You may set a default image or handle it as needed
            holder.itemsImage.setImageResource(R.drawable.logo);
        }
    }

    @Override
    public int getItemCount() {
        return orderList != null ? orderList.size() : 0;
    }
    private boolean isFirstOccurrence(int userId, int currentPosition, List<orderget> ordergets) {
        for (int i = 0; i < currentPosition; i++) {
            orderget Orders = ordergets.get(i);
            if (Orders.getUsers() != null && Orders.getUsers().getId() == userId) {
                return false;
            }
        }
        return true;
    }
    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemsImage;
        TextView tvItemsName;
        TextView tvItemPrice;
        TextView tvQuantity;

        public ViewHolder( View itemView) {
            super(itemView);
            itemsImage = itemView.findViewById(R.id.itemsImage);
            tvItemsName = itemView.findViewById(R.id.tvItemNames);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
        }
    }
}
