package com.example.kfries2.model;

public class orderget {
        private int OrderID;
        private orderItemsGet OrderItems;
        private OrderStatus OrderStatus;
        private String OrderDate;
        private String Remarks;
        private String OrderTime;
        private String TotalPrice;
        private  User users;

    public orderget() {
    }

    public orderget(int orderID, orderItemsGet orderItems, OrderStatus status, String orderDate, String remarks, String orderTime,String totalPrice, User Users) {
        OrderID = orderID;
        OrderItems = orderItems;
        OrderStatus = status;
        OrderDate = orderDate;
        Remarks = remarks;
        OrderTime = orderTime;
        TotalPrice = totalPrice;
        users=Users;
    }

    public String getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int orderID) {
        OrderID = orderID;
    }

    public orderItemsGet getOrderItemsID() {
        return OrderItems;
    }

    public void setOrderItemsID(orderItemsGet orderItemsID) {
        OrderItems = orderItemsID;
    }

    public OrderStatus getStatusID() {
        return OrderStatus;
    }

    public void setStatusID(OrderStatus statusID) {
        OrderStatus = statusID;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String orderDate) {
        OrderDate = orderDate;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String remarks) {
        Remarks = remarks;
    }

    public String getOrderTime() {
        return OrderTime;
    }

    public void setOrderTime(String orderTime) {
        OrderTime = orderTime;
    }

    public User getUsers() {
        return users;
    }

    public void setUsers(User users) {
        this.users = users;
    }

    @Override
    public String toString() {
        return "orderget{" +
                "OrderID=" + OrderID +
                ", OrderItems=" + OrderItems +
                ", OrderStatus=" + OrderStatus +
                ", OrderDate='" + OrderDate + '\'' +
                ", Remarks='" + Remarks + '\'' +
                ", OrderTime='" + OrderTime + '\'' +
                ", TotalPrice='" + TotalPrice + '\'' +
                ", users=" + users +
                '}';
    }
}
