package com.example.kfries2.remote;


import com.example.kfries2.model.orderget;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface OrderGetService {
    @GET("api/Orders")
    Call<List<orderget>> getAllOrderItems(@Header("api-key")String apiKey);
}
