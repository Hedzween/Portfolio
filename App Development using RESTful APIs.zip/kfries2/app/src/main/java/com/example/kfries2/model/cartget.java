package com.example.kfries2.model;

import java.util.List;

public class cartget {
    private int CartId;
    private Items Items;  //  the foreign key
    private int Quantity;

    public cartget() {}

    public cartget(int CartId,Items Item, int Quantity){
        this.CartId = CartId;
        this.Items = Item;
        this.Quantity = Quantity;
    }
    public int getCartId() {
        return CartId;
    }

    public void setCartId(int cartId) {
        CartId = cartId;
    }

    public Items getItems() {
        return Items;
    }

    public void setItems(Items Items) {
        this.Items = Items;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    public double calculateTotal(double currentTotal) {
        // Assuming getQuantity() is a method that returns the quantity for a specific item
        return currentTotal + getQuantity() * getItems().getPrices().doubleValue();
    }
    @Override
    public String toString() {
        return "Cart{" +
                "CartId=" + CartId +
                ", Item=" + Items +
                ", Quantity=" + Quantity +
                '}';
    }
}