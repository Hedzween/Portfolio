package com.example.kfries2.remote;

import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.Orders;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface OrderService {
    @POST("api/Orders")
    Call<Orders> addOrder(@Header("api-key")String apiKey, @Body Orders Orders);

    @POST("api/Orders/update")
    Call<Orders> updateOrder(@Header("api-key")String apiKey, @Body Orders orders);

    @POST("api/Orders/delete/{OrderID}")
    Call<DeleteResponse> deleteOrder(@Header("api-key") String apiKey, @Path("OrderID") int OrderID);
}
