package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.model.Cart;
import com.example.kfries2.model.Items;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.cartget;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.CartGetService;
import com.example.kfries2.remote.CartService;
import com.example.kfries2.remote.MenuService;
import com.google.android.material.navigation.NavigationView;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddCart extends AppCompatActivity {

    private MenuService menuService;
    private CartService cartService;
    private Context context;
    private Items items;
    private CartGetService cartGetService;
    private User user;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_cart);

        context = this;
        Intent intent = getIntent();
        int itemID = intent.getIntExtra("ItemsID", -1);
        Integer itemImage = getIntent().getIntExtra("ItemImage", 0);

        user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        menuService = ApiUtils.getMenuService();

        menuService.getItems(user.getToken(), itemID).enqueue(new Callback<Items>() {
            @Override
            public void onResponse(Call<Items> call, Response<Items> response) {
                if (response.isSuccessful()) {
                    items = response.body();
                    if (items != null) {
                        ImageView ivItemImage = findViewById(R.id.ItemsImage);
                        TextView tvItemName = findViewById(R.id.ItemName);
                        TextView tvDescription = findViewById(R.id.description);
                        TextView tvWarning = findViewById(R.id.warning);
                        TextView tvPrice = findViewById(R.id.price);
                        Button btnAddCart = findViewById(R.id.btnAddCart);

                        ivItemImage.setImageResource(itemImage);
                        tvItemName.setText(items.getItemName());
                        tvPrice.setText(items.getPrice());
                        tvDescription.setText(items.getDescription());
                        tvWarning.setText(items.getWarning());
                        // Inside the onClick method of btnAddCart
                        btnAddCart.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                cartService = ApiUtils.getCartService();
                                cartGetService = ApiUtils.getCartGetService();
                                Call<List<cartget>> cartgetCall = cartGetService.getAllCart(user.getToken());
                                cartgetCall.enqueue(new Callback<List<cartget>>() {
                                    @Override
                                    public void onResponse(Call<List<cartget>> call, Response<List<cartget>> response) {
                                        if (response.isSuccessful()) {
                                            List<cartget> cartList = response.body();

                                            // Checking if the item with a given itemId exists
                                            cartget existingCartItem = getCartItemById(cartList, itemID);

                                            if (existingCartItem == null) {
                                                // Item doesn't exist, add a new cart item
                                                Cart cart = new Cart(0, itemID, 1);
                                                addNewCartItem(cart);
                                            } else {
                                                // Item already exists, ignore the addition
                                                Toast.makeText(context, "Item already in the cart.", Toast.LENGTH_LONG).show();
                                            }
                                        } else {
                                            Log.e("MyApp:", "Response not successful. Error code: " + response.code());
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<List<cartget>> call, Throwable t) {
                                        displayAlert("Error retrieving cart data");
                                        Log.e("MyApp:", "Error retrieving cart data: " + t.getMessage());
                                    }
                                });
                            }
                        });
                    } else {
                        Log.e("MyApp:", "Items object is null");
                    }
                } else {
                    Log.e("MyApp:", "Response not successful. Error code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<Items> call, Throwable t) {
                Toast.makeText(context, "Error connecting", Toast.LENGTH_LONG).show();
            }
        });

        //menu side bar navigation
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view2);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {

                int id = item.getItemId();

                if (id == R.id.nav_account) {

                }else if (id==R.id.Cart) {
                    doCart1();
                }else if (id==R.id.myOrder) {
                    doOrder();
                }
                else if (id == R.id.nav_settings) {

                } else if (id == R.id.nav_logout) {
                    doLogout();
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {
        SharedPrefManager.getInstance(getApplicationContext()).logout();

        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        finish();
        startActivity(new Intent(getApplicationContext(), login.class));
    }

    //navigation to cart
    public void doCart1() {
        startActivity(new Intent(this, com.example.kfries2.Cart.class));
        finish();
    }
    public void doOrder() {
        startActivity(new Intent(this, Receipt.class));
        finish();
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private cartget getCartItemById(List<cartget> cartList, int itemId) {
        if (cartList != null) {
            for (cartget cartItem : cartList) {
                if (cartItem.getItems() != null && cartItem.getItems().getItemID() == itemId) {
                    return cartItem;
                }
            }
        }
        return null;
    }

    //add new cart
    private void addNewCartItem(Cart cart) {
        Call<Cart> call = cartService.addCart(user.getToken(), cart);
        call.enqueue(new Callback<Cart>() {
            @Override
            public void onResponse(Call<Cart> call, Response<Cart> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());
                Log.d("MyApp:", "Response JSON: " + response.body());
                if (response.code() == 401) {
                    displayAlert("Invalid session. Please re-login");
                    return;
                }

                if (response.isSuccessful()) {
                    Cart addedCart = response.body();
                    if (addedCart != null) {
                        Toast.makeText(context, "Added successfully.", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(context, mainmenu.class);
                        startActivity(intent);
                        finish();
                    } else {
                        displayAlert("Add menu failed.");
                    }
                } else {
                    displayAlert("Add menu failed. Error code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<Cart> call, Throwable t) {
                displayAlert("Add menu failed. Error: " + t.getMessage());
            }
        });
    }
}
