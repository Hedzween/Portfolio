package com.example.kfries2.remote;

public class ApiUtils {

    // REST API server URL
    public static final String BASE_URL = "https://kfries.000webhostapp.com/prestige/";

    // return UserService instance
    public static UserService getUserService() {
        return RetrofitClient.getClient(BASE_URL).create(UserService.class);
    }
    public static MenuService getMenuService(){
        return RetrofitClient.getClient(BASE_URL).create(MenuService.class);
    }

    public static CartService getCartService(){
        return RetrofitClient.getClient(BASE_URL).create(CartService.class);
    }
    public static CartGetService getCartGetService(){
        return RetrofitClient.getClient(BASE_URL).create(CartGetService.class);
    }
    public static OrderItemsService getOrderItemsService(){
        return RetrofitClient.getClient(BASE_URL).create(OrderItemsService.class);
    }
    public static OrderItemsGetService getOrderItemsGetService(){
        return RetrofitClient.getClient(BASE_URL).create(OrderItemsGetService.class);
    }
    public static OrderService getOrderService(){
        return RetrofitClient.getClient(BASE_URL).create(OrderService.class);
    }
    public static OrderGetService getOrderGetService(){
        return RetrofitClient.getClient(BASE_URL).create(OrderGetService.class);
    }
    public static SalesDailyService getSalesDailyService(){
        return RetrofitClient.getClient(BASE_URL).create(SalesDailyService.class);
    }
}