package com.example.kfries2.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.kfries2.AddCart;
import com.example.kfries2.R;
import com.example.kfries2.model.Items;

import java.util.List;

public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.ViewHolder> {

    /**
     * Create ViewHolder class to bind list item view
     */
    class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView iView;
        public TextView tvName;
        public TextView tvPrice;

        public ViewHolder(View itemView) {
            super(itemView);
            iView = (ImageView) itemView.findViewById(R.id.iView);
            tvName = (TextView) itemView.findViewById(R.id.tvName);
            tvPrice = (TextView) itemView.findViewById(R.id.tvPrice);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    currentPos = getAdapterPosition();
                    // Perform any click action you need
                    Items selectedItem = itemList.get(currentPos);

                    // Start the AddCart activity and pass necessary data
                    Intent intent = new Intent(mContext, AddCart.class);
                    intent.putExtra("ItemsID", selectedItem.getItemID());
                    intent.putExtra("ItemImage", resourceId[currentPos]); // Use currentPos to get the resource ID
                    mContext.startActivity(intent);
                }
            });
        }
    }
            //itemView.setOnLongClickListener(this);
       // }
/*
        @Override
      public boolean onLongClick(View view) {
            currentPos = getAdapterPosition();
            return false;
        }

    }

     */

    private List<Items> itemList;
    private Context mContext;
    private int currentPos;

    public int getCurrentPos() {
        return currentPos;
    }

    public ItemsAdapter(Context context, List<Items> listData) {
        itemList = listData;
        mContext = context;
    }

    private Context getmContext(){return mContext;}
    private Integer resourceId[] ={R.drawable.bibimbap,R.drawable.kongguksu,R.drawable.naengmyeon,R.drawable.gimbap,
            R.drawable.jjangmyeon,R.drawable.bulgogi,R.drawable.peachsoda,R.drawable.bananamilk,R.drawable.strawberrymilk,
            R.drawable.melonmilk,R.drawable.kimchi,R.drawable.tteok,R.drawable.tteokbokki};

    public Integer[] getResourceId(){return resourceId;}
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the single item layout
        View view = inflater.inflate(R.layout.item_layout, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Items item = itemList.get(position);
        int currResource = resourceId[position];
        holder.iView.setImageResource(currResource);
        holder.tvName.setText(item.getItemName());
        holder.tvPrice.setText(item.getPrice());
    }

    @Override
    public int getItemCount() {
        return itemList != null ? itemList.size() : 0;
    }

    public Items getSelectedItem() {
        if (currentPos >= 0 && itemList != null && currentPos < itemList.size()) {
            return itemList.get(currentPos);
        }
        return null;
    }

}
