package com.example.kfries2.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kfries2.R;
import com.example.kfries2.model.Cart;
import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.Items;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.cartget;
import com.example.kfries2.model.orderItemsGet;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.CartService;
import com.example.kfries2.remote.MenuService;
import com.example.kfries2.remote.OrderItemsGetService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private List<cartget> cartList;
    private Context mContext;
    private int currentQuantity = 0;

    CartService cartService;
    OrderItemsGetService orderItemsGetService;

    public CartAdapter(Context context, List<cartget> listData) {
        cartList = listData;
        mContext = context;
    }
    public List<cartget> getCartItems() {
        return cartList;
    }
    public int getCurrentQuantity() {
        return currentQuantity;
    }
    private Integer resourceId[] ={R.drawable.bibimbap,R.drawable.kongguksu,R.drawable.naengmyeon,R.drawable.gimbap,
            R.drawable.jjangmyeon,R.drawable.bulgogi,R.drawable.peachsoda,R.drawable.bananamilk,R.drawable.strawberrymilk,
            R.drawable.melonmilk,R.drawable.kimchi,R.drawable.tteok,R.drawable.tteokbokki
    };

    public Integer[] getResourceId(){return resourceId;}
    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.add_cart_detail, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        User user = SharedPrefManager.getInstance(mContext.getApplicationContext()).getUser();
        cartget cart = cartList.get(position);

        if (cart != null && cart.getItems() != null) {
            Log.d("MyApp", "Item Name: " + cart.getItems().getItemName());
            Log.d("MyApp", "Item Price: " + cart.getItems().getPrice());
            holder.tvItemsName.setText(cart.getItems().getItemName());
            holder.tvItemPrice.setText(cart.getItems().getPrice());
            holder.tvQuantity.setText(String.valueOf(cart.getQuantity()));
            holder.increment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    buttonFuncIn(holder, cart);
                }
            });
            holder.decrement.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    buttonFuncDe(holder, cart);
                }
            });
            setImageResourceBasedOnItemName(holder, cart.getItems().getItemName());

        } else {
            Log.e("MyApp", "Items object is null or cartget is null for position: " + position);
            // Hide the itemView by setting visibility to GONE
            holder.itemView.setVisibility(View.GONE);
        }
    }
    public BigDecimal calcTotalPrice() {
        BigDecimal totalPrice = BigDecimal.ZERO;

        if (cartList != null) {
            for (cartget cart : cartList) {
                if (cart != null && cart.getItems() != null && cart.getItems().getPrices() != null) {
                    BigDecimal itemPrice = cart.getItems().getPrices();
                    int quantity = cart.getQuantity();
                    BigDecimal subtotal = itemPrice.multiply(BigDecimal.valueOf(quantity));
                    totalPrice = totalPrice.add(subtotal);
                }
            }
        }

        return totalPrice;
    }

    private void sentQuantity(cartget cart2) {
        User user = SharedPrefManager.getInstance(mContext.getApplicationContext()).getUser();
        cartService = ApiUtils.getCartService();

        for (cartget cart : cartList) {
            // Initialize cart1 for each iteration
            Cart cart1 = new Cart();

            cart1.setCartId(cart.getCartId());
            cart1.setItems(cart.getItems().getItemID());
            cart1.setQuantity(cart.getQuantity());

            Log.d("My App: ", "Cart Info: " + cart1.toString());

            Call<Cart> call = cartService.updateCart(user.getToken(), cart1);
            call.enqueue(new Callback<Cart>() {
                @Override
                public void onResponse(Call<Cart> call, Response<Cart> response) {
                    if (response.isSuccessful()) {

                        Log.d("MyApp:", "Updated successfully");
                    } else {
                        Log.d("MyApp:", "Request: " + call.request().toString());
                        Log.e("MyApp:", "Update failed. Error code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<Cart> call, Throwable t) {
                    Log.e("MyApp:", "Update failed. Error: " + t.getMessage());
                }
            });
        }
    }
    public void buttonFuncIn(ViewHolder holder, cartget cart){
        int quantity = cart.getQuantity() + 1;
        holder.tvQuantity.setText(String.valueOf(quantity));
        currentQuantity = quantity;
        int position = holder.getAdapterPosition();
        if (position != RecyclerView.NO_POSITION) {
            cartList.get(position).setQuantity(quantity);
            BigDecimal prices = cart.getItems().getPrices().multiply(BigDecimal.valueOf(quantity));
            holder.tvItemPrice.setText("RM " + prices.toPlainString());
        }
        cart.setQuantity(currentQuantity);
        sentQuantity(cart);
        ((com.example.kfries2.Cart) mContext).updateTotalPrice(cartList);
    }
    public void buttonFuncDe(ViewHolder holder,cartget cart) {
        int quantity = cart.getQuantity();
        if (quantity > 1) {
            quantity=quantity-1;
            // If quantity is greater than 1, decrement the quantity
            holder.tvQuantity.setText(String.valueOf(quantity));
            currentQuantity = quantity;
            // Update the quantity in the actual cartList
            int position = holder.getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                cartList.get(position).setQuantity(quantity);
                BigDecimal prices = cart.getItems().getPrices().multiply(BigDecimal.valueOf(quantity));
                holder.tvItemPrice.setText("RM " + prices.toPlainString());
            }
        } else {
            User user = SharedPrefManager.getInstance(mContext.getApplicationContext()).getUser();
            cartService = ApiUtils.getCartService();
            Call<DeleteResponse> deleteResponseCall = cartService.deleteCart(user.getToken(), cart.getCartId());
            deleteResponseCall.enqueue(new Callback<DeleteResponse>() {
                @Override
                public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                    if (response.isSuccessful()) {
                        // Handle successful deletion, you might want to update your UI or take other actions
                        // For example, you can remove the item from your list or update the RecyclerView
                        int position = holder.getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            // Assuming you have a method to remove the item from your list
                            removeItem(position);
                            // Notify the adapter about the item removal
                            notifyItemRemoved(position);
                            // Notify the adapter that the data set has changed
                            notifyItemRangeChanged(position, getItemCount());
                        }
                    } else {
                        // Handle unsuccessful deletion
                        // You might want to show an error message or take appropriate action
                        Log.e("MyApp", "Delete failed. Error code: " + response.code());
                        // Show an error message to the user, for example:
                        Toast.makeText(mContext, "Failed to delete item. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<DeleteResponse> call, Throwable t) {
                    // Handle failure
                    // You might want to show an error message or take appropriate action
                    Log.e("MyApp", "Delete failed. Error: " + t.getMessage());
                    // Show an error message to the user, for example:
                    Toast.makeText(mContext, "Failed to delete item. Please try again.", Toast.LENGTH_SHORT).show();
                }
            });
        }
        cart.setQuantity(currentQuantity);
        sentQuantity(cart);
        ((com.example.kfries2.Cart) mContext).updateTotalPrice(cartList);
    }



    private void removeItem(int position) {
        // Implement your logic to remove the item at the specified position
        cartList.remove(position);
        // Notify the adapter that the item is removed
        notifyItemRemoved(position);
    }
    private void setImageResourceBasedOnItemName(ViewHolder holder, String itemName) {
        Integer currResource = null;

        // Assuming that the ItemName and resourceId arrays have the same order
        for (int i = 0; i < resourceId.length; i++) {
            String resourceName = mContext.getResources().getResourceEntryName(resourceId[i]).toLowerCase();

            if (itemName.toLowerCase().replaceAll("\\s", "").equals(resourceName.toLowerCase().replaceAll("\\s", ""))) {
                currResource = resourceId[i];
                break;
            }
        }

        if (currResource != null) {
            holder.itemsImage.setImageResource(currResource);
        } else {
            // Handle the case where the resource for the itemName is not found
            // You may set a default image or handle it as needed
            holder.itemsImage.setImageResource(R.drawable.logo);
        }
    }
    @Override
    public int getItemCount() {
        return cartList != null ? cartList.size() : 0;
    }

    public void clearCartItems() {
        cartList.clear();
        notifyDataSetChanged();
    }
    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemsImage;
        TextView tvItemsName;
        TextView tvItemPrice;
        TextView tvQuantity;
        Button increment;
        Button decrement;

        ViewHolder(View itemView) {
            super(itemView);
            itemsImage = itemView.findViewById(R.id.itemsImage);
            tvItemsName = itemView.findViewById(R.id.tvItemNames);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            tvQuantity = itemView.findViewById(R.id.quantity);
            increment = itemView.findViewById(R.id.increment);
            decrement = itemView.findViewById(R.id.decrement);
        }
    }

}
