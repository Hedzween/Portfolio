package com.example.kfries2.model;


public class OrderItems {
    private int OrderItemsID;
    private int items;
    private int Quantity;

    public OrderItems(){}

    public OrderItems(int orderItemsID, int items, int quantity) {
        OrderItemsID = orderItemsID;
        this.items = items;
        Quantity = quantity;
    }

    public int getOrderItemsID() {
        return OrderItemsID;
    }

    public void setOrderItemsID(int orderItemsID) {
        OrderItemsID = orderItemsID;
    }

    public int getItems() {
        return items;
    }

    public void setItems(int items) {
        this.items = items;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    @Override
    public String toString() {
        return "OrderItems{" +
                "OrderItemsID=" + OrderItemsID +
                ", items=" + items +
                ", Quantity=" + Quantity +
                '}';
    }
}
