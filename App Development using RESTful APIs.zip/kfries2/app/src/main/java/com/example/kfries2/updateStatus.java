package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.adapter.adapter;
import com.example.kfries2.model.Orders;
import com.example.kfries2.model.SalesDaily;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.orderget;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.OrderGetService;
import com.example.kfries2.remote.OrderService;
import com.example.kfries2.remote.SalesDailyService;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class updateStatus extends AppCompatActivity {
    private OrderService orderService;
    private OrderGetService orderGetService;
    private Context context;
    private RecyclerView itemOrder;
    private adapter orderAdapter;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private SalesDailyService salesDailyService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status);
        context=this;
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        Intent receivedIntent = getIntent();
        int OrderId= receivedIntent.getIntExtra("OrderID",-1);
        String Total= receivedIntent.getStringExtra("TotalPrice");
        int UserID = receivedIntent.getIntExtra("UserID",-1);
        String remark = receivedIntent.getStringExtra("Remark");
        TextView Remark =findViewById(R.id.remark);
        Remark.setText(remark);
        TextView orderId = findViewById(R.id.orderId);
        orderId.setText(String.valueOf(OrderId));
        TextView price = findViewById(R.id.prices);
        price.setText("RM"+Total);

        itemOrder = findViewById(R.id.itemOrder);
        registerForContextMenu(itemOrder);
        updateListView(UserID);

        orderGetService= ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("MyApp: ","Response: "+response.raw().toString());
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }
                List<orderget> ordergets=response.body();
                List<orderget> filteredOrders = filterOrdersByUserId(ordergets, UserID);
                for (orderget order : filteredOrders) {
                    CheckBox OrderSampai = findViewById(R.id.OrderSampai);
                    CheckBox OrderSiap = findViewById(R.id.OrderSiap);
                    if (OrderSampai.isChecked()) {
                        updateStatus(filteredOrders,UserID);
                        OrderSampai.setChecked(true);
                    }
                    if(order.getStatusID().getStatusID()==2){
                        OrderSampai.setChecked(true);
                    }
                    if (OrderSiap.isChecked()) {
                        OrderSiap.setChecked(true);
                        updateStatus3(filteredOrders, UserID);
                    }
                    if(order.getStatusID().getStatusID()==3){
                        OrderSiap.setChecked(true);
                        saveSales(order.getTotalPrice());
                        OrderSampai.setChecked(true);
                    }
                }
                if(ordergets!= null) {
                    orderAdapter = new adapter(context, filteredOrders);
                    itemOrder.setAdapter(orderAdapter);
                    LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    itemOrder.setLayoutManager(layoutManager);
                }

            }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_SHORT);
                Log.e("MyApp: ", t.getMessage());
            }
        });
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view1);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {
                    // Handle "My Account" click
                    // Add your logic here
                } else if (id == R.id.nav_settings) {
                    // Handle "Settings" click
                    // Add your logic here
                } else if (id == R.id.btnLogout) {
                    doLogout();
                }

                // Close the drawer after handling item click
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void doLogout() {
        // clear the shared preferences
        SharedPrefManager.getInstance(getApplicationContext()).logout();
        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();
        // forward to LoginActivity
        startActivity(new Intent(this, login.class));
        finish();
    }


    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
    private void updateListView(int UserID){
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderGetService = ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("MyApp: ", "Response: " + response.raw().toString());
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }
                List<orderget> ordergets = response.body();
                List<orderget> filteredOrders = filterOrdersByUserId(ordergets, UserID);
                for (orderget order : filteredOrders) {
                    CheckBox OrderSampai= findViewById(R.id.OrderSampai);
                    CheckBox OrderSiap = findViewById(R.id.OrderSiap);
                    if(OrderSampai.isChecked()){
                        updateStatus(filteredOrders,UserID);
                        OrderSampai.setChecked(true);
                    }
                    if (OrderSiap.isChecked()) {
                        OrderSiap.setChecked(true);
                        updateStatus3(filteredOrders, UserID);
                        OrderSampai.setChecked(true);
                    }
                }
                orderAdapter = new adapter(context, filteredOrders);
                itemOrder.setAdapter(orderAdapter);
                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                itemOrder.setLayoutManager(layoutManager);
            }
            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }
    public void updateStatus(List<orderget> Orders1, int userID){
        User user= SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderService = ApiUtils.getOrderService();
        for(orderget orders: Orders1) {
            Orders orders1 = new Orders();
            orders1.setStatusID(2);
            orders1.setOrderDate(orders.getOrderDate());
            orders1.setOrderTime(orders.getOrderTime());
            orders1.setRemark(orders.getRemarks());
            orders1.setOrderID(orders.getOrderID());
            orders1.setOrderItemsID(orders.getOrderItemsID().getOrderItemsID());
            orders1.setUser(userID);
            Log.d("myApp:","Order Info: "+orders1.toString());
            orderService.updateOrder(user.getToken(), orders1).enqueue(new Callback<Orders>() {
                @Override
                public void onResponse(Call<Orders> call, Response<Orders> response) {
                    if (response.isSuccessful()) {
                        Log.d("MyApp:", "Updated successfully");
                    } else {
                        Log.d("MyApp:", "Request: " + call.request().toString());
                        Log.e("MyApp:", "Update failed. Error code: " + response.code());
                    }
                }
                @Override
                public void onFailure(Call<Orders> call, Throwable t) {
                    Log.e("MyApp:", "Update failed. Error: " + t.getMessage());
                }
            });
        }
    }

    public void updateStatus3(List<orderget> order1, int userID){
        User user= SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderService = ApiUtils.getOrderService();
        for(orderget orders:order1) {
            Orders orders1 = new Orders();
            orders1.setStatusID(3);
            orders1.setOrderDate(orders.getOrderDate());
            orders1.setOrderTime(orders.getOrderTime());
            orders1.setRemark(orders.getRemarks());
            orders1.setOrderID(orders.getOrderID());
            orders1.setOrderItemsID(orders.getOrderItemsID().getOrderItemsID());
            orders1.setUser(userID);
            Log.d("myApp:", "Order Info: " + orders1.toString());
            orderService.updateOrder(user.getToken(), orders1).enqueue(new Callback<Orders>() {
                @Override
                public void onResponse(Call<Orders> call, Response<Orders> response) {
                    if (response.isSuccessful()) {
                        Log.d("MyApp:", "Updated successfully");
                    } else {
                        Log.d("MyApp:", "Request: " + call.request().toString());
                        Log.e("MyApp:", "Update failed. Error code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<Orders> call, Throwable t) {
                    Log.e("MyApp:", "Update failed. Error: " + t.getMessage());
                }
            });
        }
    }

    private void saveSales(String total){
        TimeZone malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur");
        Calendar currentDateTime = Calendar.getInstance(malaysiaTimeZone);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String currentDateString = dateFormat.format(currentDateTime.getTime());

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String currentTimeString = timeFormat.format(currentDateTime.getTime());
        User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();
        BigDecimal total1= new BigDecimal(total);
        salesDailyService=ApiUtils.getSalesDailyService();
        SalesDaily salesDaily = new SalesDaily(0,total1,currentDateString);
        Log.d("AdminMenu:","SalesDaily: "+salesDaily.toString());
        salesDailyService.addSales(user.getToken(), salesDaily).enqueue(new Callback<SalesDaily>() {
            @Override
            public void onResponse(Call<SalesDaily> call, Response<SalesDaily> response) {
                if (response.isSuccessful() || response.code() == 201) {
                    Log.d("MyApp:", "SalesNotedDown successfully");
                } else {
                    try {
                        Log.d("MyApp:", "Error Response: " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Log.d("MyApp:", "Request Payload: " + call.request().body().toString());
                Log.d("MyApp:", "Request: " + call.request().toString());
            }

            @Override
            public void onFailure(Call<SalesDaily> call, Throwable t) {
                Log.e("MyApp:", "Order failed. Error: " + t.getMessage());
            }
        });
    }
    private List<orderget> filterOrdersByUserId(List<orderget> orderList, int userId) {
        List<orderget> filteredList = new ArrayList<>();

        for (orderget order : orderList) {
            if (order.getUsers() != null && order.getUsers().getId() == userId) {
                filteredList.add(order);
            }
        }

        return filteredList;
    }

}