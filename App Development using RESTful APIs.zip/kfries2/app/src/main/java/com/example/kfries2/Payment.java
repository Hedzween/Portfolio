package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.adapter.CartAdapter;
import com.example.kfries2.adapter.OrderAdapter;
import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.OrderItems;
import com.example.kfries2.model.Orders;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.cartget;
import com.example.kfries2.model.orderItemsGet;
import com.example.kfries2.model.orderget;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.CartGetService;
import com.example.kfries2.remote.CartService;
import com.example.kfries2.remote.OrderGetService;
import com.example.kfries2.remote.OrderItemsGetService;
import com.example.kfries2.remote.OrderService;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Payment extends AppCompatActivity {
    private Context context;
    private OrderGetService orderGetService;
    private OrderItemsGetService orderItemsGetService;
    private OrderService orderService;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private CartService cartDelService;
    private CartGetService cartGetService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        context = this;
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        Intent receivedIntent = getIntent();
        String totalString = receivedIntent.getStringExtra("TotalPrice");
        String remarkString = receivedIntent.getStringExtra("Remark");
        TextView name= findViewById(R.id.name);
        name.setText(user.getUsername());
        Button btnComplete= findViewById(R.id.Complete);
        btnComplete.setText("Pay RM "+ totalString );
        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readOrderItems(remarkString,totalString);
                readCart();

            }
        });

        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view1);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {
                    // Handle "My Account" click
                    // Add your logic here
                }else if (id==R.id.Cart) {
                    doCart1();
                }else if (id==R.id.myOrder) {
                    doOrder();
                }
                else if (id == R.id.nav_settings) {
                    // Handle "Settings" click
                    // Add your logic here
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }

                // Close the drawer after handling item click
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {

        // clear the shared preferences
        SharedPrefManager.getInstance(getApplicationContext()).logout();

        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        // forward to LoginActivity
        finish();
        startActivity(new Intent(getApplicationContext(), login.class));
    }
    public void doCart1() {
        startActivity(new Intent(this, Cart.class));
        finish();
    }
    public void doOrder() {
        startActivity(new Intent(this, Receipt.class));
        finish();
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showOrderCompletedDialog(String totalString, String currentDateString, String currentTimeString,String remarkString) {
        // Create a dialog to show the order completion details
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.cardview_completed); // Replace with the actual name of your cardview layout file

        CardView cardView = dialog.findViewById(R.id.cardView);
        cardView.setRadius(getResources().getDimension(R.dimen.cardCornerRadius));
        // Customize the content of the dialog as needed
        // For example, you can set text, set listeners for buttons, etc.

        Button mainMenuButton = dialog.findViewById(R.id.MainMenu);
        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Main Menu button click
                Intent intent = new Intent(context, mainmenu.class);
                intent.putExtra("TotalPrice",totalString);
                intent.putExtra("Date", currentDateString);
                intent.putExtra("Time", currentTimeString);
                intent.putExtra("Remark", remarkString);
                startActivity(intent);
                dialog.dismiss();
            }
        });

        Button orderButton = dialog.findViewById(R.id.Receipt);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle Order button click
                Intent intent = new Intent(context, Receipt.class);
                intent.putExtra("TotalPrice",totalString);
                intent.putExtra("Date", currentDateString);
                intent.putExtra("Time", currentTimeString);
                intent.putExtra("Remark", remarkString);
                startActivity(intent);
                dialog.dismiss();
            }
        });

        // Show the dialog
        dialog.show();
    }
    public DateTime dateTime(){
        TimeZone malaysiaTimeZone = TimeZone.getTimeZone("Asia/Kuala_Lumpur");
        Calendar currentDateTime = Calendar.getInstance(malaysiaTimeZone);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String currentDateString = dateFormat.format(currentDateTime.getTime());

        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String currentTimeString = timeFormat.format(currentDateTime.getTime());
        return new DateTime(currentDateString, currentTimeString);
    }
    public void saveOrders(List<Integer>OrderIds,String remark,List<orderget>ordergets, String total){
        DateTime dateTime = dateTime();
        String currentDateString = dateTime.getCurrentDate();
        String currentTimeString = dateTime.getCurrentTime();
        User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();
        int userID = user.getId();
        orderService=ApiUtils.getOrderService();
        for (Integer orderId : OrderIds) {
            if (!isOrdered(orderId, ordergets)) {
                Orders orders = new Orders(0, orderId, 1, currentDateString, remark, currentTimeString,total,userID);
                Call<Orders> ordersCall = orderService.addOrder(user.getToken(), orders);
                Log.d("My App: ", "Orders: " + orders.toString());
                ordersCall.enqueue(new Callback<Orders>() {
                    @Override
                    public void onResponse(Call<Orders> call, Response<Orders> response) {

                        if (response.isSuccessful() || response.code() == 201) {
                            Log.d("MyApp:", "Ordered successfully");
                        } else {
                            try {
                                Log.d("MyApp:", "Error Response: " + response.errorBody().string());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        Log.d("MyApp:", "Request Payload: " + call.request().body().toString());
                        Log.d("MyApp:", "Request: " + call.request().toString());
                    }

                    @Override
                    public void onFailure(Call<Orders> call, Throwable t) {
                        Log.e("MyApp:", "Order failed. Error: " + t.getMessage());
                    }
                });
            } else {
                // OrderId already exists in OrderItems, you can handle this case if needed
                Log.d("MyApp:", "OrderId " + orderId + " already exists in OrderItems");
            }
        }
    }
    public void readOrderItems(String remarkString,String totalString) {
        User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();
        orderItemsGetService = ApiUtils.getOrderItemsGetService();
        // Make the context final

        orderItemsGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderItemsGet>>() {

            @Override
            public void onResponse(Call<List<orderItemsGet>> call, Response<List<orderItemsGet>> response) {
                if (response.isSuccessful()) {
                    List<orderItemsGet> Oi = response.body();
                    if (Oi != null && !Oi.isEmpty()) {
                        // Collect order IDs in a list
                        List<Integer> orderIDs = new ArrayList<>();
                        for (orderItemsGet orderItem : Oi) {
                            orderIDs.add(orderItem.getOrderItemsID());
                        }
                        readOrder(user,orderIDs,remarkString,totalString);
                    } else {
                        Log.d("MyApp:", "JSON Response: " + response.body());
                        Log.e("MyApp:", "Error: " + response.code());
                    }
                }
            }
            @Override
            public void onFailure(Call<List<orderItemsGet>> call, Throwable t) {
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());

            }
        });
    }

    public void readOrder(User user, List<Integer> OrderIds, String remark, String total) {
        orderGetService = ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("MyApp:", "JSON Response: " + response.body());
                Log.d("MyApp: ", "Response: " + response.raw().toString());
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }
                if (response.isSuccessful()) {
                    List<orderget> ordergets = response.body();
                    if (ordergets != null) {
                        // Check the count of unique user IDs
                        int uniqueUserCount = countUniqueUserIds(ordergets);

                        // Specify the threshold for the number of users
                        int maxUsers = 10;

                        if (uniqueUserCount >= maxUsers) {
                            // Toast a message indicating that the restaurant is busy
                            Toast.makeText(context, "Restaurant is busy. Please try again later.", Toast.LENGTH_SHORT).show();
                        } else {
                            // Proceed with saving orders
                            DateTime dateTime = dateTime();
                            String currentDateString = dateTime.getCurrentDate();
                            String currentTimeString = dateTime.getCurrentTime();
                            showOrderCompletedDialog(total,currentDateString,currentTimeString,remark);
                            saveOrders(OrderIds, remark, ordergets, total);
                        }
                    } else {
                        // Handle the case where ordergets is null
                        DateTime dateTime = dateTime();
                        String currentDateString = dateTime.getCurrentDate();
                        String currentTimeString = dateTime.getCurrentTime();
                        showOrderCompletedDialog(total,currentDateString,currentTimeString,remark);
                        saveOrderNull(OrderIds, remark, total);
                    }
                } else {
                    Log.e("myApp: ", "Error: " + response.raw());
                }
            }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }

    // Helper method to count unique user IDs
    private int countUniqueUserIds(List<orderget> ordergets) {
        HashSet<Integer> uniqueUserIds = new HashSet<>();

        for (orderget order : ordergets) {
            if (order.getUsers() != null) {
                uniqueUserIds.add(order.getUsers().getId());
            }
        }

        return uniqueUserIds.size();
    }


    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private boolean isOrdered(int orderItemId, List<orderget> orderGets) {
        if (orderGets == null) {
            return false;  // or handle this case according to your requirements
        }
        for (orderget orderGet : orderGets) {
            Log.d("MyApp", "OrderItems: " + orderGet.toString());

            // Check if getOrderItemsID() is not null before accessing its properties
            if (orderGet.getOrderItemsID() != null && orderGet.getOrderItemsID().getOrderItemsID() == orderItemId) {
                return true;
            }
        }
        return false;
    }
    public void saveOrderNull(List<Integer>OrderIds,String remark, String total){
        DateTime dateTime = dateTime();
        String currentDateString = dateTime.getCurrentDate();
        String currentTimeString = dateTime.getCurrentTime();
        User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();
        int userID = SharedPrefManager.getInstance(context.getApplicationContext()).getUser().getId();
        orderService=ApiUtils.getOrderService();
        for (Integer orderId : OrderIds) {
                Orders orders = new Orders(0, orderId, 1, currentDateString, remark, currentTimeString,total,userID);
                Call<Orders> ordersCall = orderService.addOrder(user.getToken(), orders);
                Log.d("My App: ", "Orders: " + orders.toString());
                ordersCall.enqueue(new Callback<Orders>() {
                    @Override
                    public void onResponse(Call<Orders> call, Response<Orders> response) {

                        if (response.isSuccessful() || response.code() == 201) {
                            Log.d("MyApp:", "Ordered successfully");
                        } else {
                            try {
                                Log.d("MyApp:", "Error Response: " + response.errorBody().string());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        Log.d("MyApp:", "Request Payload: " + call.request().body().toString());
                        Log.d("MyApp:", "Request: " + call.request().toString());
                    }

                    @Override
                    public void onFailure(Call<Orders> call, Throwable t) {
                        Log.e("MyApp:", "Order failed. Error: " + t.getMessage());
                    }
                });
        }
    }
    public void readCart(){
        User user=SharedPrefManager.getInstance(getApplicationContext()).getUser();
        cartGetService=ApiUtils.getCartGetService();
        cartGetService.getAllCart(user.getToken()).enqueue(new Callback<List<cartget>>() {
            @Override
            public void onResponse(Call<List<cartget>> call, Response<List<cartget>> response) {
                if (response.isSuccessful()) {
                    if (response.code() == 401) {
                        Log.e("Payment:", "Read Cart: Error");
                    }
                    List<cartget> cart = response.body();
                    if (cart != null) {
                        for (cartget cart1 : cart) {
                            removeCart(user, cart1.getCartId());
                        }
                    } else {
                        Log.e("Payment:", "Cart response body is null");
                    }
                } else {
                    // Handle the case where the response is not successful
                    Log.e("Payment:", "Unsuccessful response. Code: " + response.code());
                }
            }
            @Override
            public void onFailure(Call<List<cartget>> call, Throwable t) {
            Log.e("Payment","Error Read Failure");
            }
        });
    }

    public void removeCart(User user,int cartId) {
        cartDelService = ApiUtils.getCartService();
            Call<DeleteResponse> deleteResponseCall = cartDelService.deleteCart(user.getToken(), cartId);
            deleteResponseCall.enqueue(new Callback<DeleteResponse>() {
                @Override
                public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                    if (response.isSuccessful()) {
                        Log.d("Receipt:", "Delete Cart: " + response.code());
                    } else {

                        Log.e("Receipt", "Delete cart failed. Error code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<DeleteResponse> call, Throwable t) {
                    Log.e("Receipt", "Delete cart. Error: " + t.getMessage());

                }
            });
        }

}