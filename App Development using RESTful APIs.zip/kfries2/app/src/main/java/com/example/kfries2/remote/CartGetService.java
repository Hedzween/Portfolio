package com.example.kfries2.remote;

import com.example.kfries2.model.Cart;
import com.example.kfries2.model.cartget;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface CartGetService {
    @GET("api/Cart")
    Call<List<cartget>> getAllCart(@Header("api-key")String api_key);

    @GET("api/Cart/{CartId}")
    Call<cartget> getCart(@Header("api-key")String api_key, @Path("CartId")int CartId);

}
