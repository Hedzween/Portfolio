package com.example.kfries2.model;

import java.math.BigDecimal;

public class SalesDaily {
    private int SalesID;
    private BigDecimal TotalAmount;
    private String Date;

    public int getSalesID() {
        return SalesID;
    }

    public void setSalesID(int salesID) {
        SalesID = salesID;
    }

    public BigDecimal getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        TotalAmount = totalAmount;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public SalesDaily() {
    }

    public SalesDaily(int salesID, BigDecimal totalAmount, String date) {
        SalesID = salesID;
        TotalAmount = totalAmount;
        Date = date;
    }

    @Override
    public String toString() {
        return "SalesDaily{" +
                "SalesID=" + SalesID +
                ", TotalAmount=" + TotalAmount +
                ", Date='" + Date + '\'' +
                '}';
    }
}
