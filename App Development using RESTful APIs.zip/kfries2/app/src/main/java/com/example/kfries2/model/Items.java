package com.example.kfries2.model;


import java.math.BigDecimal;

public class Items {

    private int ItemID;

    private String ItemName;

    private String Description;
    private String Warning;
    private String Price;
    private BigDecimal prices;
    private menu Menu;


    public Items() {}
    public Items(int ItemID, String ItemName,String Description,String Warning, String price, BigDecimal prices, menu Menu ){
        this.ItemID= ItemID;
        this.ItemName=ItemName;
        this.Price=price;
        this.Description=Description;
        this.Warning=Warning;
        this.prices=prices;
        this.Menu=Menu;
    }

    public menu getMenu() {
        return Menu;
    }

    public void setMenu(menu menu) {
        Menu = menu;
    }

    public BigDecimal getPrices() {
        return prices;
    }

    public void setPrices(BigDecimal prices) {
        this.prices = prices;
    }

    public int getItemID() {
        return ItemID;
    }

    public void setItemID(int itemID) {
        ItemID = itemID;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price = price;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getWarning() {
        return Warning;
    }

    public void setWarning(String warning) {
        Warning = warning;
    }

    @Override
    public String toString() {
        return "Items{" +
                "ItemID=" + ItemID +
                ", ItemName='" + ItemName + '\'' +
                ", Description='" + Description + '\'' +
                ", Warning='" + Warning + '\'' +
                ", Price='" + Price + '\'' +
                '}';
    }
}
