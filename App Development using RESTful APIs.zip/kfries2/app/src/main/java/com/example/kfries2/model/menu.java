package com.example.kfries2.model;

public class menu {
    private int MenuId;
    private String MenuName;

    public menu(){}

    public menu(int MenuId, String MenuName){
        this.MenuId=MenuId;
        this.MenuName=MenuName;
    }

    public int getMenuId() {
        return MenuId;
    }

    public void setMenuId(int menuId) {
        MenuId = menuId;
    }

    public String getMenuName() {
        return MenuName;
    }

    public void setMenuName(String menuName) {
        MenuName = menuName;
    }

    @Override
    public String toString() {
        return "menu{" +
                "MenuId=" + MenuId +
                ", MenuName='" + MenuName + '\'' +
                '}';
    }
}
