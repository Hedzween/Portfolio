package com.example.kfries2.adapter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import com.example.kfries2.R;
import com.example.kfries2.model.Items;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.orderget;
import com.example.kfries2.updateStatus;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashSet;
import java.util.List;

public class AdminAdapter extends RecyclerView.Adapter<AdminAdapter.ViewHolder> {
    private List<orderget> ordergetList;
    private Context mContext;
    private int currentPos;
    private BigDecimal totalSum = BigDecimal.ZERO;
    public BigDecimal getTotalSum() {
        return totalSum;
    }

    public AdminAdapter(Context context, List<orderget> listData) {
        ordergetList = listData;
        mContext = context;
    }
    public List<orderget> getOrdergetList(){ return  ordergetList;}
    private Context getmContext(){return mContext;}
    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.orders, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        orderget orderget = ordergetList.get(position);

        if(orderget!=null && orderget.getUsers()!=null) {
            int userId = orderget.getUsers().getId();


            // Check if the order belongs to the current user and is the first occurrence of that user ID
            if (isCheckId(userId, ordergetList) && isFirstOccurrence(userId, position, ordergetList)) {
                String OrderId = String.valueOf(orderget.getOrderID());
                holder.tvOrderId.setText(OrderId);
                holder.tvPrices.setText(orderget.getTotalPrice());
                calculate();
            } else {
                // If it's not the first occurrence, you can hide or set values to an empty string
                holder.itemView.setVisibility(View.GONE);
            }
        }

    }


    private boolean isFirstOccurrence(int userId, int currentPosition, List<orderget> ordergets) {
        for (int i = 0; i < currentPosition; i++) {
            orderget Orders = ordergets.get(i);
            if (Orders.getUsers() != null && Orders.getUsers().getId() == userId) {
                return false;
            }
        }
        return true;
    }
    public int getCurrentPos() {
        return currentPos;
    }
    public orderget getSelectedItem() {
        if (currentPos >= 0 && ordergetList != null && currentPos < ordergetList.size()) {
            return ordergetList.get(currentPos);
        }
        return null;
    }
    @Override
    public int getItemCount() {
        return ordergetList!=null? ordergetList.size():0;
    }
     class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvOrderId;
        TextView tvPrices;
        public ViewHolder(View itemView){
            super(itemView);
            tvPrices=itemView.findViewById(R.id.tvPrices);
            tvOrderId=itemView.findViewById(R.id.tvOrderId);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentPos=getAdapterPosition();
                    User user = SharedPrefManager.getInstance(getmContext().getApplicationContext()).getUser();

                    orderget selectedItem= ordergetList.get(currentPos);
                    Intent intent = new Intent(mContext, updateStatus.class);
                    intent.putExtra("OrderID", selectedItem.getOrderID());
                    intent.putExtra("TotalPrice", selectedItem.getTotalPrice());
                    intent.putExtra("UserID",selectedItem.getUsers().getId());
                    intent.putExtra("Remark", selectedItem.getRemarks());
                    mContext.startActivity(intent);
                }
            });
        }
    }
    public int getImageResourceId(String itemName) {
        Integer currResource = null;

        // Assuming that the ItemName and resourceId arrays have the same order
        for (int i = 0; i < resourceId.length; i++) {
            String resourceName = mContext.getResources().getResourceEntryName(resourceId[i]).toLowerCase();

            if (itemName.toLowerCase().replaceAll("\\s", "").equals(resourceName.toLowerCase().replaceAll("\\s", ""))) {
                currResource = resourceId[i];
                break;
            }
        }

        return (currResource != null) ? currResource : R.drawable.logo;
    }

    private boolean isCheckId(int userId, List<orderget> ordergets){
        if(ordergets == null){
            return false;
        }
        for (orderget Orders: ordergets){
            Log.d("isCheckId: ", " Orders" + Orders.toString());
            if(Orders.getUsers() != null && Orders.getUsers().getId() == userId) {
                return true;
            }
        }
        return false;
    }

    private void calculate() {
        // Create a set to keep track of users for whom the total has been calculated
        HashSet<Integer> calculatedUsers = new HashSet<>();

        StringBuilder totalSumString = new StringBuilder();

        // Iterate through the orders in reverse order to calculate total for the first occurrence
        for (int i = ordergetList.size() - 1; i >= 0; i--) {
            orderget order = ordergetList.get(i);

            // Add a null check for order.getUsers()
            if (order.getUsers() != null) {
                int userId = order.getUsers().getId();

                // Check if the user is not already calculated and is the first occurrence
                if (!calculatedUsers.contains(userId) && isFirstOccurrence(userId, i, ordergetList)) {
                    String orderTotal = order.getTotalPrice();

                    if (orderTotal != null && !orderTotal.isEmpty()) {
                        // Append the user's total to the StringBuilder
                        if (totalSumString.length() > 0) {
                            totalSumString.append(", ");

                        }
                        totalSumString.append("User ID ").append(userId).append(": ").append(orderTotal);

                        // Add the user to the set to mark as calculated
                        calculatedUsers.add(userId);
                    }
                }
            }
        }

        // Now, totalSumString contains the string representation of the total for each user
        String finalString = totalSumString.toString();
        Log.d("Total String: ", finalString);
    }
    private Integer resourceId[] ={R.drawable.bibimbap,R.drawable.kongguksu,R.drawable.naengmyeon,R.drawable.gimbap,
            R.drawable.jjangmyeon,R.drawable.bulgogi,R.drawable.peachsoda,R.drawable.bananamilk,R.drawable.strawberrymilk,
            R.drawable.melonmilk,R.drawable.kimchi,R.drawable.tteok,R.drawable.tteokbokki};
    public BigDecimal convertStringToDecimal(String input) {
        try {
            // Parse the input string to a BigDecimal
            BigDecimal decimalValue = new BigDecimal(input);

            // Set the scale to 2 (for two decimal points) and rounding mode
            decimalValue = decimalValue.setScale(2, RoundingMode.HALF_UP);

            return decimalValue;
        } catch (NumberFormatException e) {
            // Handle the case where the input string is not a valid number
            e.printStackTrace(); // Or log the error
            return BigDecimal.ZERO; // Or another default value
        }
    }
    public void performCalculation() {
        calculate();
    }


}
