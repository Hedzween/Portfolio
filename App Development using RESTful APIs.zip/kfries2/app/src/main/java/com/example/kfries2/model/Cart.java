package com.example.kfries2.model;

public class Cart {
    private int CartId;
    private int items;  //  the foreign key
    private int Quantity;

    public Cart() {}

    public Cart(int CartId,int item, int Quantity){
        this.CartId = CartId;
        this.items = item;
        this.Quantity = Quantity;
    }

    public int getCartId() {
        return CartId;
    }

    public void setCartId(int cartId) {
        CartId = cartId;
    }

    public int getItems() {
        return items;
    }

    public void setItems(int items) {
        this.items = items;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "CartId=" + CartId +
                ", item=" + items +
                ", Quantity=" + Quantity +
                '}';
    }
}