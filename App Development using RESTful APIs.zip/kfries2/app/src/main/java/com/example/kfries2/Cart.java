package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.adapter.CartAdapter;
import com.example.kfries2.adapter.ItemsAdapter;
import com.example.kfries2.model.DeleteResponse;
import com.example.kfries2.model.Items;
import com.example.kfries2.model.OrderItems;
import com.example.kfries2.model.SalesDaily;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.cartget;
import com.example.kfries2.model.orderItemsGet;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.CartGetService;
import com.example.kfries2.remote.CartService;
import com.example.kfries2.remote.MenuService;
import com.example.kfries2.remote.OrderItemsGetService;
import com.example.kfries2.remote.OrderItemsService;
import com.example.kfries2.remote.SalesDailyService;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Cart extends AppCompatActivity {
    private Context context;
    private CartAdapter cartAdapter;
    private RecyclerView cartItem,sideDish;
    private CartGetService cartService;
    private MenuService itemService;
    private OrderItemsService orderItemsService;
    private OrderItemsGetService orderItemsGetService;
    private String remarkText = "";
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
private ItemsAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        context = this;
        cartItem = findViewById(R.id.cartItem);
        registerForContextMenu(cartItem);
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        // Initialize cart service
        cartService = ApiUtils.getCartGetService();
        // Update the cart list view
        updateListView1();
        sideDish = findViewById(R.id.SideDish);
        registerForContextMenu(sideDish);
        itemService = ApiUtils.getMenuService();
        updateListView();
        itemService.getAllItems(user.getToken()).enqueue(new Callback<List<Items>>() {
            @Override
            public void onResponse(Call<List<Items>> call, Response<List<Items>> response) {
                Log.d("MyApp: ", "Response: " + response.raw().toString());
                List<Items> items = response.body();
                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                sideDish.setLayoutManager(layoutManager);
                adapter = new ItemsAdapter(context, items);
                sideDish.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Items>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_SHORT);
                Log.e("MyApp: ", t.getMessage());
            }
        });
        Button btnCheckout = findViewById(R.id.checkout);
        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BigDecimal totalpriceWithFee = updateTotalPrice(cartAdapter.getCartItems());
                readOrderItems();
                insertRemark();
                Intent intent = new Intent(context, Payment.class);
                intent.putExtra("TotalPrice",totalpriceWithFee.toString());
                intent.putExtra("Remark",remarkText);
                // Start the Payment activity or perform any other required actions
                startActivity(intent);
            }
        });
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view2);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {
                    // Handle "My Account" click
                    // Add your logic here
                }else if (id==R.id.Cart) {
                    doCart1();
                }else if (id==R.id.myOrder) {
                    doOrder();
                }
                else if (id == R.id.nav_settings) {
                    // Handle "Settings" click
                    // Add your logic here
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }

                // Close the drawer after handling item click
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {

        // clear the shared preferences
        SharedPrefManager.getInstance(getApplicationContext()).logout();

        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        // forward to LoginActivity
        finish();
        startActivity(new Intent(getApplicationContext(), login.class));
    }
    public void doCart1() {
        startActivity(new Intent(this, Cart.class));
        finish();
    }
    public void doOrder() {
        startActivity(new Intent(this, Receipt.class));
        finish();
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void insertRemark() {
        EditText etRemark = findViewById(R.id.Remark);

        // Check if etRemark is not null
        if (etRemark != null) {
            // Get the text from etRemark
            remarkText = etRemark.getText().toString();

            // Check if remarkText is null or empty
            if (remarkText == null || remarkText.trim().isEmpty()) {
                // Set a default value if remarkText is null or empty
                etRemark.setText("No remark");
                remarkText = "No remark";
                Log.d("My App: ", "Remark set to default: " + remarkText);
            } else {
                // Log the non-null remarkText
                Log.d("My App: ", "Remark: " + remarkText);
            }
        } else {
            // Log a message or handle the case when etRemark is null
            Log.d("My App: ", "etRemark is null");
        }
    }

    public void sentOrderItems(List<orderItemsGet> existingOrderItems) {
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderItemsService = ApiUtils.getOrderItemsService();
        List<cartget> cartItems = cartAdapter.getCartItems();
        if(cartItems!=null){
        for (cartget cart : cartItems) {
                OrderItems orderItems = new OrderItems(0, cart.getItems().getItemID(), cart.getQuantity());
                Call<OrderItems> call = orderItemsService.addOrderItems(user.getToken(), orderItems);
                Log.d("MyApp: ", "OrderItems: " + orderItems.toString());
                call.enqueue(new Callback<OrderItems>() {
                    @Override
                    public void onResponse(Call<OrderItems> call, Response<OrderItems> response) {
                        if (response.isSuccessful()) {
                            Log.d("MyApp:", "Added successfully");
                        } else {
                            if (response.errorBody() != null) {
                                try {
                                    Log.d("MyApp:", "Error Response: " + response.errorBody().string());
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            Log.d("MyApp:", "Request Payload: " + call.request().body().toString());
                            Log.d("MyApp:", "Request: " + call.request().toString());
                            Log.e("MyApp:", "Update failed. Error code: " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<OrderItems> call, Throwable t) {
                        Log.e("MyApp:", "Update failed. Error: " + t.getMessage());
                    }
                });
            }
         }

        Toast.makeText(context, "Add Your Order First", Toast.LENGTH_SHORT);
    }

    private void updateListView1() {
        // Get user info from SharedPreferences
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        // Execute the call and send the user token when sending the query
        cartService.getAllCart(user.getToken()).enqueue(new Callback<List<cartget>>() {
            @Override
            public void onResponse(Call<List<cartget>> call, Response<List<cartget>> response) {
                // For debug purposes
                Log.d("MyApp:", "Response: " + response.raw().toString());

                // Token is not valid/expired
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }

                // Get list of cart objects from the response
                List<cartget> cart = response.body();

                // Initialize the adapter
                cartAdapter = new CartAdapter(context, cart);

                // Set the adapter to the RecyclerView
                cartItem.setAdapter(cartAdapter);

                // Set layout to RecyclerView
                cartItem.setLayoutManager(new LinearLayoutManager(context));
                BigDecimal totalPrice = cartAdapter.calcTotalPrice();

// Format and set the total price to the TextView
                String formattedTotal = String.format("%.2f", totalPrice);
                TextView TotalPrice = findViewById(R.id.TotalPrice);
                TotalPrice.setText("RM " + formattedTotal);
                BigDecimal totalPriceWithFee = totalPrice.add(new BigDecimal("2.00"));
                String formattedTotalWithFee = String.format("%.2f", totalPriceWithFee);

// Update the second TextView with processing fee
                TextView tvTotalPriceWithFee = findViewById(R.id.TotalPrice1);
                tvTotalPriceWithFee.setText("RM " + formattedTotalWithFee);
// Call the method to update total price
                updateTotalPrice(cart);

            }

            @Override
            public void onFailure(Call<List<cartget>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }
    // Change private to package-private (default access level)
    public BigDecimal updateTotalPrice(List<cartget> cartItems) {
        BigDecimal totalPrice = calculateTotal(cartItems);

        // Null check for totalPrice
        if (totalPrice != null) {
            String formattedTotal = String.format("%.2f", totalPrice);
            TextView totalPriceTextView = findViewById(R.id.TotalPrice);
            totalPriceTextView.setText("RM " + formattedTotal);

            // Add processing fee
            BigDecimal totalPriceWithFee = totalPrice.add(new BigDecimal("2.00"));
            String formattedTotalWithFee = String.format("%.2f", totalPriceWithFee);

            // Update the second TextView with processing fee
            TextView tvTotalPriceWithFee = findViewById(R.id.TotalPrice1);
            tvTotalPriceWithFee.setText("RM " + formattedTotalWithFee);

            return totalPriceWithFee;
        } else {
            // Handle the case where totalPrice is null (display an error message, log, etc.)
            // You may return a default value or throw an exception based on your application's logic.
            return BigDecimal.ZERO; // Default value, adjust as needed
        }
    }

    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
    private void updateListView () {
        // get user info from SharedPreferences
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        // get book service instance
        itemService = ApiUtils.getMenuService();

        // execute the call. send the user token when sending the query
        itemService.getAllItems(user.getToken()).enqueue(new Callback<List<Items>>() {
            @Override
            public void onResponse(Call<List<Items>> call, Response<List<Items>> response) {
                // for debug purpose
                Log.d("MyApp:", "Response: " + response.raw().toString());

                // token is not valid/expired
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }

                // Get list of book object from response
                List<Items> items = response.body();


                // initialize adapter
                adapter = new ItemsAdapter(context, items);

                // set adapter to the RecyclerView
                sideDish.setAdapter(adapter);

                // set layout to recycler view
                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
                sideDish.setLayoutManager(layoutManager);
            }

            @Override
            public void onFailure(Call<List<Items>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }
    private BigDecimal calculateTotal(List<cartget> cart) {
        BigDecimal total = BigDecimal.ZERO;

        if (cart != null) {
            for (cartget cartItem : cart) {
                if (cartItem != null && cartItem.getItems() != null) {
                    BigDecimal prices = cartItem.getItems().getPrices();
                    if (prices != null) {
                        BigDecimal itemTotal = BigDecimal.valueOf(cartItem.getQuantity()).multiply(prices);
                        total = total.add(itemTotal);
                    }
                }
            }
        }
        return total;
    }


    public void readOrderItems() {
        User user = SharedPrefManager.getInstance(context.getApplicationContext()).getUser();
        orderItemsGetService = ApiUtils.getOrderItemsGetService();
        orderItemsGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderItemsGet>>() {

            @Override
            public void onResponse(Call<List<orderItemsGet>> call, Response<List<orderItemsGet>> response) {
                if (response.isSuccessful()) {
                    List<orderItemsGet> Oi = response.body();
                    sentOrderItems(Oi);
                    } else {
                        Log.d("MyApp:", "JSON Response: " + response.body());
                        Log.e("MyApp:", "Error: " + response.code());
                    }

            }
            @Override
            public void onFailure(Call<List<orderItemsGet>> call, Throwable t) {
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());

            }
        });

    }

}