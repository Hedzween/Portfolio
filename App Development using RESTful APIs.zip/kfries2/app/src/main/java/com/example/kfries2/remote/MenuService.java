package com.example.kfries2.remote;

import com.example.kfries2.model.Items;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;

public interface MenuService {

    @GET("api/Items") // Fixed the string here
    Call<List<Items>> getAllItems(@Header("api-key") String api_key);

    @GET("api/Items/{ItemID}")
    Call<Items> getItems(@Header("api-key") String api_key, @Path("ItemID") int ItemID); // Fixed the parameter name
}


