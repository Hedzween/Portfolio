package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.adapter.AdminAdapter;
import com.example.kfries2.model.SalesDaily;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.model.orderget;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.OrderGetService;


import com.example.kfries2.remote.SalesDailyService;
import com.google.android.material.navigation.NavigationView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminMenu extends AppCompatActivity {

    OrderGetService orderGetService;
    RecyclerView OrdersReceive;
    Context context;
    AdminAdapter adapter;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    int currentPos;
    SalesDailyService salesDailyService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);
        context=this;
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        TextView tvUser=findViewById(R.id.users);
        tvUser.setText("Your Task List:" + user.getUsername());

        OrdersReceive=findViewById(R.id.OrdersReceived);
        registerForContextMenu(OrdersReceive);
        updateListView();
        readSales();
        orderGetService = ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("AdminMenu: ","Response: "+response.raw().toString());
                List<orderget> Orderget= response.body();
                List<orderget> filterstatus= filterOrderByStatus(Orderget);
                adapter=new AdminAdapter(context,filterstatus);
                OrdersReceive.setAdapter(adapter);
                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                OrdersReceive.setLayoutManager(layoutManager);
            }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context,"Error connecting to the server",Toast.LENGTH_SHORT);
                Log.e("Receipt: ",t.getMessage());
            }
        });


        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {

                }
                else if (id == R.id.nav_settings) {

                } else if (id == R.id.btnLogout) {
                    doLogout();
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {

        SharedPrefManager.getInstance(getApplicationContext()).logout();

        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        startActivity(new Intent(this, login.class));
        finish();
    }

    private void updateListView(){
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        orderGetService=ApiUtils.getOrderGetService();
        orderGetService.getAllOrderItems(user.getToken()).enqueue(new Callback<List<orderget>>() {
            @Override
            public void onResponse(Call<List<orderget>> call, Response<List<orderget>> response) {
                Log.d("AdminMenu: ","Response: "+response.raw().toString());
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }
                List<orderget> Orderget= response.body();
                List<orderget> filterstatus= filterOrderByStatus(Orderget);
                adapter=new AdminAdapter(context,filterstatus);
                OrdersReceive.setAdapter(adapter);
                LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                OrdersReceive.setLayoutManager(layoutManager);
            }

            @Override
            public void onFailure(Call<List<orderget>> call, Throwable t) {
                Toast.makeText(context,"Error connecting to the server",Toast.LENGTH_SHORT);
                Log.e("Receipt: ",t.getMessage());
            }
        });
    }
    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        orderget selectedOrder = adapter.getSelectedItem();
        Log.d("MyApp", "selected "+selectedOrder.toString());
        if (item.getItemId() == R.id.add_cart) {
            currentPos = adapter.getCurrentPos();
            doViewDetails(selectedOrder);
            return true;
        }
        return super.onContextItemSelected(item);
    }
    private void doViewDetails(orderget selectedItem) {
        Log.d("MyApp:", "viewing details "+selectedItem.toString());
        Intent intent = new Intent(context, updateStatus.class);
        intent.putExtra("OrderID", selectedItem.getOrderID());
        intent.putExtra("TotalPrice", selectedItem.getTotalPrice());
        intent.putExtra("UserID", selectedItem.getUsers().getId());
        intent.putExtra("Remark", selectedItem.getRemarks());
        startActivity(intent); // Remove the duplicate line
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private List<orderget> filterOrderByStatus(List<orderget> ordergetList) {
        List<orderget> filteredList = new ArrayList<>();
        for (orderget order : ordergetList) {
            Log.d("Order Status", "StatusID: " + (order.getStatusID() != null ? order.getStatusID().getStatusID() : "null"));
            if (order.getStatusID() != null && order.getStatusID().getStatusID() != 3) {
                filteredList.add(order);
            }
        }
        return filteredList;
    }

    public void readSales() {
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        salesDailyService = ApiUtils.getSalesDailyService();

        salesDailyService.readSales(user.getToken()).enqueue(new Callback<List<SalesDaily>>() {
            @Override
            public void onResponse(Call<List<SalesDaily>> call, Response<List<SalesDaily>> response) {
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }

                List<SalesDaily> sales = response.body();
                BigDecimal total = BigDecimal.ZERO; // Initialize total as BigDecimal.ZERO

                for (SalesDaily SD : sales) {
                    BigDecimal sale = SD.getTotalAmount();
                    total = total.add(sale);
                }

                // Convert BigDecimal to String or double as needed
                String totalString = total.toString();

                TextView revenue = findViewById(R.id.revenue);
                revenue.setText("Today Total Revenue: RM" + totalString);
            }

            @Override
            public void onFailure(Call<List<SalesDaily>> call, Throwable t) {
                // Handle failure here
            }
        });
    }
}