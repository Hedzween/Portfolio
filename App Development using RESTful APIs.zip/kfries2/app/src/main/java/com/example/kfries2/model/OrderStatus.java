package com.example.kfries2.model;

public class OrderStatus {
    private int StatusID;
    private String StatusName;
    private int DurationSeconds;

    public OrderStatus() {
    }

    public OrderStatus(int statusID, String statusName, int durationSeconds) {
        StatusID = statusID;
        StatusName = statusName;
        DurationSeconds = durationSeconds;
    }

    public int getStatusID() {
        return StatusID;
    }

    public void setStatusID(int statusID) {
        StatusID = statusID;
    }

    public String getStatusName() {
        return StatusName;
    }

    public void setStatusName(String statusName) {
        StatusName = statusName;
    }

    public int getDurationSeconds() {
        return DurationSeconds;
    }

    public void setDurationSeconds(int durationSeconds) {
        DurationSeconds = durationSeconds;
    }

    @Override
    public String toString() {
        return "OrderStatus{" +
                "StatusID=" + StatusID +
                ", StatusName='" + StatusName + '\'' +
                ", DurationSeconds=" + DurationSeconds +
                '}';
    }
}
