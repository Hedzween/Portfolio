package com.example.kfries2;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kfries2.adapter.ItemsAdapter;
import com.example.kfries2.model.Items;
import com.example.kfries2.model.SharedPrefManager;
import com.example.kfries2.model.User;
import com.example.kfries2.remote.ApiUtils;
import com.example.kfries2.remote.MenuService;
import com.google.android.material.navigation.NavigationView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class mainmenu extends AppCompatActivity {

    MenuService MenuService;
    RecyclerView menuItem;
    Context context;
    ItemsAdapter adapter;

    int currentPos;
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);
        context=this;

        TextView txtuser = findViewById(R.id.txtHello);
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();
        txtuser.setText(user.getUsername());

        menuItem=findViewById(R.id.menuItem);
        registerForContextMenu(menuItem);
        updateListView();
        MenuService= ApiUtils.getMenuService();
        MenuService.getAllItems(user.getToken()).enqueue(new Callback<List<Items>>() {
            @Override
            public void onResponse(Call<List<Items>> call, Response<List<Items>> response) {
                Log.d("MyApp: ","Response: "+response.raw().toString());
                List<Items> items = response.body();
                menuItem.setLayoutManager(new GridLayoutManager(context,3));
                adapter=new ItemsAdapter(context,items);
                menuItem.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Items>> call, Throwable t) {
                Toast.makeText(context,"Error connecting to the server",Toast.LENGTH_SHORT);
                Log.e("MyApp: ",t.getMessage());
            }
        });
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.navigation_view1);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected( MenuItem item) {
                // Handle navigation view item clicks here
                int id = item.getItemId();

                if (id == R.id.nav_account) {
                    // Handle "My Account" click
                    // Add your logic here
                }else if (id==R.id.Cart) {
                    doCart1();
                }else if (id==R.id.myOrder) {
                    doOrder();
                }
                else if (id == R.id.nav_settings) {
                    // Handle "Settings" click
                    // Add your logic here
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }

                // Close the drawer after handling item click
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    public void doLogout() {
        // clear the shared preferences
        SharedPrefManager.getInstance(getApplicationContext()).logout();

        // display message
        Toast.makeText(getApplicationContext(),
                "You have successfully logged out.",
                Toast.LENGTH_LONG).show();

        // forward to LoginActivity
        finish();
        startActivity(new Intent(getApplicationContext(), login.class));
    }
    public void doCart1() {
        startActivity(new Intent(this, Cart.class));
        finish();
    }
    public void doOrder() {
        startActivity(new Intent(this, Receipt.class));
        finish();
    }

    private void updateListView () {
        // get user info from SharedPreferences
        User user = SharedPrefManager.getInstance(getApplicationContext()).getUser();

        // get book service instance
        MenuService = ApiUtils.getMenuService();

        // execute the call. send the user token when sending the query
        MenuService.getAllItems(user.getToken()).enqueue(new Callback<List<Items>>() {
            @Override
            public void onResponse(Call<List<Items>> call, Response<List<Items>> response) {
                // for debug purpose
                Log.d("MyApp:", "Response: " + response.raw().toString());

                // token is not valid/expired
                if (response.code() == 401) {
                    displayAlert("Session Invalid");
                }

                // Get list of book object from response
                List<Items> items = response.body();

                // initialize adapter
                adapter = new ItemsAdapter(context, items);

                // set adapter to the RecyclerView
                menuItem.setAdapter(adapter);

                // set layout to recycler view
                menuItem.setLayoutManager(new GridLayoutManager(context,3));

            }
            @Override
            public void onFailure(Call<List<Items>> call, Throwable t) {
                Toast.makeText(context, "Error connecting to the server", Toast.LENGTH_LONG).show();
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }
    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //do things
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Items selectedItem = adapter.getSelectedItem();
        Log.d("MyApp", "selected "+selectedItem.toString());
        if (item.getItemId() == R.id.add_cart) {
            currentPos = adapter.getCurrentPos();
            doViewDetails(selectedItem);
            return true;
        }
        return super.onContextItemSelected(item);
    }
    private void doViewDetails(Items selectedItem) {
        Log.d("MyApp:", "viewing details "+selectedItem.toString());
        Intent intent = new Intent(context, AddCart.class);
        intent.putExtra("ItemsID", selectedItem.getItemID());
        intent.putExtra("ItemImage",adapter.getResourceId()[currentPos]);
        startActivity(intent);
    }
    public boolean onOptionsItemSelected(MenuItem item){
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}