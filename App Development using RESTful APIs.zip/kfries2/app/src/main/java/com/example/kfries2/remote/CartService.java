package com.example.kfries2.remote;

import com.example.kfries2.model.Cart;
import com.example.kfries2.model.DeleteResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface CartService {

    @POST("api/Cart")
    Call<Cart> addCart(@Header("api-key")String apiKey, @Body Cart cart);

    @POST("api/Cart/delete/{CartId}")
    Call<DeleteResponse> deleteCart(@Header ("api-key") String apiKey, @Path("CartId")
    int CartId);

    @POST("api/Cart/update")
    Call<Cart> updateCart(@Header("api-key") String apiKey,@Body Cart cart);
}
